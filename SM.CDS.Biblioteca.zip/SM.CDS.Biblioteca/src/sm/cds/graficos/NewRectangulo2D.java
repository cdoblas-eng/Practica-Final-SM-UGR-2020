/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package sm.cds.graficos;

import java.awt.Color;
import java.awt.Point;
import java.awt.Rectangle;
import java.awt.geom.Point2D;

/**
 * Clase propia utilizada para representar un rectangulo en el lienzo. 
 * Hereda de la clase Figura.
 * @author Doblas
 */
public class NewRectangulo2D extends NewFigCerrada {
    
    
    /**
     * Constructor de la clase.Se obliga a crear con parametros.
     * @param p Punto de origen de la figura
     * @param color Color del trazo de la figura
     * @param color_relleno Color del relleno de la figura
     * @param grosor Grosor del trazo de la figura
     * @param relleno Tipo de relleno de la figura
     * @param alisado Alisado de la figura
     * @param transparencia Transparencia de la figura
     * @param tipoContinuidad Tipo de continuidad de la figura
     * @param imagen_relleno Imagen del relleno de la figura en el caso de estar activo
     */
    public NewRectangulo2D(Point2D p, Color color, Color color_relleno, int grosor, int relleno, boolean alisado, double transparencia, int tipoContinuidad, String imagen_relleno) {
        super();

        this.color = color;
        this.color_relleno = color_relleno;
        this.grosor = grosor;
        this.relleno = relleno;
        this.alisado = alisado;
        this.transparencia = transparencia;
        this.tipoContinuidad = tipoContinuidad;
        this.imagen_relleno = imagen_relleno;
        shape = new Rectangle((Point)p);
        
    }

    /**
     * Mueve el rectángulo de posición en el lienzo
     * @param a Punto donde se encuentra el raton en el lienzo.
     * @param pAux Punto del lienzo tomado de manera auxiliar para realizar el desplazamiento de la figura.
     */
    
    public void mover_figura(Point2D a, Point2D pAux) {
        
        Point pp =  ((Rectangle) shape).getBounds().getLocation();
            double dif_x = a.getX() - pAux.getX();
            double dif_y = a.getY() - pAux.getY();
                    
            pp.x += dif_x;
            pp.y += dif_y;
           ((Rectangle) shape).setLocation(pp);
    }
    
    @Override
    public void update_figura(Point2D p0,Point2D pf){
        ((Rectangle) shape).setFrameFromDiagonal(p0,pf);
    }
}
