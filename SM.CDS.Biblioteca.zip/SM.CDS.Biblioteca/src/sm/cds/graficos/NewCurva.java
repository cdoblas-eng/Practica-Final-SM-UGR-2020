/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package sm.cds.graficos;

import java.awt.Color;
import java.awt.geom.Point2D;
import java.awt.geom.QuadCurve2D;

/**
 * Clase propia utilizada para la representación de la curva con un punto de control
 * @author Doblas
 */
public class NewCurva extends NewFigAbierta {
    /**
     * Atributo que codifica el estado de la curva en su creación, ya que está pasa por tres estados.
     */
    int estado;
    
    public NewCurva(Point2D p, Color color, int grosor, boolean alisado, double transparencia, int tipoContinuidad) {

        super();

        this.color = color;
        this.grosor = grosor;
        this.alisado = alisado;
        this.transparencia = transparencia;
        this.tipoContinuidad = tipoContinuidad;
        estado = 0;

        QuadCurve2D q = new QuadCurve2D.Double();
        q.setCurve(p, p, p);
        shape = q;

    }

    @Override
    public void mover_figura(Point2D a, Point2D pAux) {
        double dif_x = a.getX() - pAux.getX();
        double dif_y = a.getY() - pAux.getY();
        
        Point2D p1 = new Point2D.Double (((QuadCurve2D) shape).getP1().getX() + dif_x, ((QuadCurve2D) shape).getP1().getY() + dif_y);
        Point2D p2 = new Point2D.Double (((QuadCurve2D) shape).getP2().getX() + dif_x, ((QuadCurve2D) shape).getP2().getY() + dif_y);
        Point2D pct =  ((QuadCurve2D) shape).getCtrlPt();//new Point2D.Double()
        pct.setLocation(pct.getX() + dif_x, pct.getY() + dif_y);
        
        ((QuadCurve2D) shape).setCurve( p1,pct, p2);
    }

    @Override
    public void update_figura(Point2D p0, Point2D pf) {
        if (estado == 0){
           ( (QuadCurve2D) shape).setCurve(( (QuadCurve2D) shape).getP1(), pf, pf);
        }else if (estado == 1) {
            
                ( (QuadCurve2D) shape).setCurve(( (QuadCurve2D) shape).getP1(), pf,( (QuadCurve2D) shape).getP2()) ;

        }    
    }
    

    
    public void cambiarEstado(){
        estado++;
    }

    public int getEstado() {
        return estado;
    }
    
    
    
}
