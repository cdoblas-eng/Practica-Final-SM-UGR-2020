/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package sm.cds.graficos;

import java.awt.Color;
import java.awt.geom.Line2D;
import java.awt.geom.Point2D;

/**
 * Clase propia utilizada para representar un punto en el lienzo. 
 * Hereda de la clase NewLinea2D ya que su funcionamiento es el mismo, a excepción del método contains().
 * @author Doblas
 */
public class NewPunto2D extends NewLinea2D {

    /**
     * Constructor de la clase. Se obliga a crear con parametros.
     * Las variables relleno y color relleno no se utilizan
     * @param p Punto de origen de la figura
     * @param color Color del trazo de la figura
     * @param grosor Grosor del trazo de la figura
     * @param alisado Alisado de la figura
     * @param transparencia Transparencia de la figura
     */
    public NewPunto2D(Point2D p, Color color, int grosor, boolean alisado, double transparencia) {
        super(p,color,grosor,alisado,transparencia,0);
        shape = new Line2D.Double(p, p);
        
        //Se interpreta al igual que la clase NewLinea2D
        
    }

    /**
     * Sobrecarga del método contains de la clase NewLinea2D
     *  Devuelve si un punto se encuentra contenido dentro de la figura
     * @param x Coordenada x del punto a comprobar
     * @param y Coordenada y del punto a comprobar
     * @return Variable booleana, true si se encuentra o false si está fuera.
     */
    @Override
    public boolean contains(double x, double y) {
        Point2D p = new Point2D.Double (x, y);
        return p.distance(((Line2D)(shape)).getP1()) <= 10.0;
    }

    /**
     * Sobrecarga del método contains de la clase NewLinea2D
     * Devuelve si un punto se encuentra contenido dentro de la figura
     * @param p Punto a comprobar
     * @return Variable booleana, true si se encuentra o false si está fuera.
     */
    @Override
    public boolean contains(Point2D p) {
        return p.distance(((Line2D)(shape)).getP1()) <= 10.0;
    }
    
    
    @Override
    public void update_figura(Point2D p0,Point2D pf){
       
    }
    

}

