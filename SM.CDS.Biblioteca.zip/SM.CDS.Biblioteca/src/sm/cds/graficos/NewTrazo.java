/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package sm.cds.graficos;

import java.awt.Color;
import java.awt.Graphics2D;
import java.awt.Point;
import java.awt.Rectangle;
import java.awt.geom.Line2D;
import java.awt.geom.Point2D;
import java.awt.geom.Rectangle2D;
import java.util.ArrayList;
import java.util.List;

/**
 * Clase propia utilizada para la representación de un trazo libre
 * @author Doblas
 */
public class NewTrazo extends NewFigAbierta {
    /**
     * Vector de puntos en el espacio que componen el trazo
     */
    private List<Point2D> trazo = new ArrayList();
    
    
    /**
     * Constructor de la clase NewTrazo, en el que se inicializan todos sus atributos.
     * @param p
     * @param color
     * @param grosor
     * @param alisado
     * @param transparencia
     * @param tipoContinuidad 
     */
    public NewTrazo(Point2D p, Color color, int grosor, boolean alisado, double transparencia, int tipoContinuidad){
        super();
        this.color = color;
        this.grosor = grosor;
        this.alisado = alisado;
        this.transparencia = transparencia;
        this.tipoContinuidad = tipoContinuidad;
                
    }
    
    @Override
    public void mover_figura(Point2D a, Point2D pAux) {
        
        double dif_x = a.getX() - pAux.getX();
        double dif_y = a.getY() - pAux.getY();

        for (Point2D p : trazo) { 
            p.setLocation(p.getX() + dif_x, p.getY() + dif_y);
        }
    }

    @Override
    public void update_figura(Point2D p0, Point2D pf) {
        Point2D.Double p_nuevo = new Point2D.Double( pf.getX(),pf.getY());
        trazo.add(p_nuevo);
    }
    
    @Override
    public void pintar_figura(Graphics2D g2d){     
//        for (NewPunto2D s : trazo) { //Para cada figura del vector
//            s.pintar_figura(g2d); //Pinta cada figura        
//        }
        NewLinea2D segmento;
        for (int i = 0 ; i < trazo.size() - 1 ; i++) {
            segmento = new NewLinea2D (trazo.get(i), color, grosor, alisado, transparencia, tipoContinuidad);
            ((Line2D.Double) segmento.get_Shape()).setLine(trazo.get(i), trazo.get(i+1));
            segmento.pintar_figura(g2d);
        }
        
        if (edicion){
            Rectangle2D visualizar = this.getBounds();
            
            visualizar.setFrame(visualizar.getX()- 20, visualizar.getY() - 20, visualizar.getWidth() + 40, visualizar.getHeight() + 40);
            NewRectangulo2D edit = new NewRectangulo2D(new Point(0,0), Color.BLACK, Color.BLACK, 1, 0, false, 100, 1, "");
            edit.shape = visualizar;
            edit.pintar_figura(g2d);
        }
    }
    
    @Override
    public boolean contains(Point2D p) {
        boolean dev = false;
        for (Point2D pt : trazo) { 
            if (pt.distance(p) <= 10.0){
                dev = true;
                break;
            }
        }
        return dev;
    }

    @Override
    public Rectangle getBounds() {
        Rectangle devolver;
        double x_min, x_max, y_min, y_max,w,h;
        x_min = 1000.0;
        x_max = 0.0;
        y_min= 1000.0;
        y_max = 0.0;
        
        for (Point2D pt : trazo) { 
            x_min = Math.min(x_min, pt.getX());
            x_max = Math.max(x_max, pt.getX());
            y_min = Math.min(y_min, pt.getY());
            y_max = Math.max(y_max, pt.getY());
        }
        
        w = x_max - x_min;
        h = y_max - y_min;
        
        
        devolver = new Rectangle((int)x_min,(int)y_min,(int)w,(int)h);
        return devolver;
    }
}
