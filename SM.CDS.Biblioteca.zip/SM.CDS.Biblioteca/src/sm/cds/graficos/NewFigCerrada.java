/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package sm.cds.graficos;

import java.awt.Color;
import java.awt.GradientPaint;
import java.awt.Graphics2D;
import java.awt.TexturePaint;
import java.awt.geom.Point2D;
import java.awt.image.BufferedImage;
import java.io.File;
import javax.imageio.ImageIO;

/**
 * Clase utilizada para representar las figuras que tienen un area, o forman un recinto, está clase tendrá nuevos atributos relacionados con el relleno.
 * @author Doblas
 */
public abstract class NewFigCerrada extends NewFigura {

    /**
     * Tipo de relleno de la figura
     */
    int relleno = 0;
    
    /**
     * Color del relleno de la figura
     */
    Color color_relleno = Color.BLACK;
    
    /**
     * Imagen del relleno de la figura
     */
    String imagen_relleno = "";
    
    /**
     * Constructor de la clase NewFigCerrada, tan solo llama al método de la clase padre
     */
    public NewFigCerrada(){
        super();
    }
    
    /**
     * Se encarga de pintar la figura en el lienzo con los atributos de una figura cerrada
     * @param g2d Variable de gráficos que se modificará para pintar la figura conforme a sus atributos. Se introducirá por parámetro desde el método Paint() del lienzo.
     */
    @Override
    public void pintar_figura(Graphics2D g2d){
        
        super.pintar_figura(g2d);
        
        Point2D pc1 = new Point2D.Double(shape.getBounds().getCenterX(),shape.getBounds().getCenterY());
        Point2D pc2 = new Point2D.Double(shape.getBounds().getCenterX(),shape.getBounds().getCenterY());
        
        GradientPaint rellenar;
        switch (relleno){            
            case 1: //RELLENO LISO
                g2d.setColor(color_relleno);
                g2d.fill(shape);               
            break;
            
            case 2: //RELLENO DEGRADADO HORIZONTAL
                
                pc1.setLocation( pc1.getX()  - ( shape.getBounds().width / 2 ), pc1.getY());
                pc2.setLocation( pc2.getX()  + ( shape.getBounds().width / 2 ), pc2.getY());                
               
                rellenar = new GradientPaint(pc1, color, pc2, color_relleno);
                g2d.setPaint(rellenar);
                g2d.fill(shape);
            break;
            
            case 3: //RELLENO DEGRADADO VERTICAL
                pc1.setLocation( pc1.getX() , pc1.getY() + ( shape.getBounds().height / 2 ));
                pc2.setLocation( pc2.getX() , pc2.getY() - ( shape.getBounds().height / 2 )) ;
                
                rellenar = new GradientPaint(pc1, color, pc2, color_relleno);
                g2d.setPaint(rellenar);
                g2d.fill(shape);
            break;
            
            case 4: //RELLENO CON IMAGEN 
                //File f = new File ("C:\\Users\\Doblas\\Documents\\NetBeansProjects\\Practica_Final\\src\\texturas\\textura2.jpg");

                File a = new File ("");
                File f = new File (a.getAbsolutePath() + "\\src\\texturas\\" + imagen_relleno);

                try{                  
                BufferedImage img = ImageIO.read(f); //new BufferedImage(500, 500, BufferedImage.TYPE_INT_RGB);
                TexturePaint texture = new TexturePaint(img, shape.getBounds() );
                g2d.setPaint(texture);
                g2d.fill(shape);
                
                }catch (Exception ex){
                    System.err.println("ERROR");
                }
                    
            break;
            
            default: //POR DEFECTO SE TOMA SIN RELLENO
                
            break;        
    }
    }
    
    /**
     * Devuelve el color de relleno de la figura
     * @return Color de relleno
     */
    public Color getColor_relleno() {
        return color_relleno;
    }

    /**
     * Establece el color de relleno de una figura
     * @param color_relleno Color de relleno a establecer
     */
    public void setColor_relleno(Color color_relleno) {
        this.color_relleno = color_relleno;
    }
    
        /**
     * Devuelve el tipo de relleno de la figura
     * @return Variable relleno
     */
    public int getRelleno() {
        return relleno;
    }

    /**
     * Establece el tipo de relleno de la figura. Las figuras abiertas lo implementan para que siempre se establezca a 0
     * @param relleno Entero con el tipo de relleno
     */
    public void setRelleno(int relleno) {
        this.relleno = relleno;
    }

    /**
     *
     * @return
     */
    public String getImagen_relleno() {
        return imagen_relleno;
    }

    /**
     *
     * @param imagen_relleno
     */
    public void setImagen_relleno(String imagen_relleno) {
        this.imagen_relleno = imagen_relleno;
    }
    
    
}
  
    

