/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package sm.cds.graficos;

import java.awt.AlphaComposite;
import java.awt.BasicStroke;
import java.awt.Color;
import java.awt.Composite;
import java.awt.Graphics2D;
import java.awt.Point;
import java.awt.Rectangle;
import java.awt.RenderingHints;
import java.awt.Shape;
import java.awt.geom.AffineTransform;
import java.awt.geom.PathIterator;
import java.awt.geom.Point2D;
import java.awt.geom.Rectangle2D;


/**
 * Clase padre de todas mis figuras utilizadas en la clase Lienzo2D. En esta clase se almacenan todos los atributos básicos de una figura
 * @author Doblas
 */
public abstract class NewFigura implements Shape {
    /**
     * NewFigura almacenada, se tendrá que inicializar en las clases que heredan de NewFigura 
     */
    Shape shape =  null;
    /**
     * Color del trazo de la figura
     */
    Color color = Color.BLACK;
    
    /**
     *Grosor de la figura
     */
    int grosor = 1;
    
    /**
     *Tipo de continuidad de la figura
     */
    int tipoContinuidad = 0;
    
    /**
     * Alisado de la figura
     */
    boolean alisado = false;
    /**
     * Transparencia de la figura
     */
    double transparencia = 100;
    
    
    /**
     * Alisado de la figura
     */
    boolean edicion = false;
    
    /**
     * Variable de la clase RenderingHints que guarda el render del alisado que se aplica en las figuras.
     * 
     */
    static final RenderingHints alisar = new RenderingHints(RenderingHints.KEY_ANTIALIASING,RenderingHints.VALUE_ANTIALIAS_ON);
    
    
    /**
     * Mueve una figura existente para editarla, es un método abstracto por lo tanto obliga a que se implemente en todas las clases hijas.
     * @param a Punto donde se encuentra el raton en el lienzo.
     * @param pAux Punto del lienzo tomado de manera auxiliar para realizar el desplazamiento de la figura.
     */
    abstract public void mover_figura(Point2D a, Point2D pAux);

    /**
     *
     * @param p0
     * @param pf
     */
    abstract public void update_figura(Point2D p0,Point2D pf);
    
    
    /**
     * Devuelve la figura almacenada de la clase Shape. Se utiliza para poder operar con ella
     * @return  NewFigura almacenada
     */
    public Shape get_Shape(){
        return shape;
    }

    /**
     *Returns an integer {@link Rectangle} that completely encloses the
     * {@code Shape}.
     * @return an integer {@code Rectangle} that completely encloses
     *                 the {@code Shape}.
     */
    @Override
    public Rectangle getBounds() {
        return shape.getBounds();        
    }

    /**
     * Tests if the specified coordinates are inside the boundary of the
     * {@code Shape}, as described by the
     * <a href="{@docRoot}/java.desktop/java/awt/Shape.html#def_insideness">
     * definition of insideness</a>.
     * @return {@code true} if the specified coordinates are inside
     *         the {@code Shape} boundary; {@code false}
     *         otherwise.
     */
    @Override
    public Rectangle2D getBounds2D() {
        return shape.getBounds2D();
    }

    /**
     * Devuelve si un punto se encuentra contenido dentro de la figura
     * @param x Coordenada x del punto 
     * @param y Coordenada y del punto
     * @return Devuelve si se encuentra contenido o no.
     */
    
    @Override 
    public boolean contains(double x, double y) {
        return shape.contains(x,y);
    }

    
    /**
     * Devuelve si un punto se encuentra contenido dentro de la figura
     * Se podría hacer abstracto para obligar su implementación, pero en mi desarrollo no ha sido necesario.
     * @param p {@code Point2D} a comprobar
     * @return Devuelve si se encuentra contenido o no.
     */
    @Override
    public boolean contains(Point2D p) {
        return shape.contains(p);
    }
    
    /**
     * Tests if the interior of the {@code Shape} entirely contains
     * the specified rectangular area.
     * @param x the X coordinate of the upper-left corner
     *          of the specified rectangular area
     * @param y the Y coordinate of the upper-left corner
     *          of the specified rectangular area
     * @param w the width of the specified rectangular area
     * @param h the height of the specified rectangular area
     * @return {@code true} if the interior of the {@code Shape}
     *          entirely contains the specified rectangular area;
     */
    @Override
    public boolean contains(double x, double y, double w, double h) {
        return shape.contains(x, y, w, h);
    }

    /**
     * Tests if the interior of the {@code Shape} intersects the
     * interior of a specified rectangular area.
    * @param x the X coordinate of the upper-left corner
     *          of the specified rectangular area
     * @param y the Y coordinate of the upper-left corner
     *          of the specified rectangular area
     * @param w the width of the specified rectangular area
     * @param h the height of the specified rectangular area
     * @return {@code true} if the interior of the {@code Shape} and
     *          the interior of the rectangular area intersect, or are
     *          both highly likely to intersect and intersection calculations
     *          would be too expensive to perform; {@code false} otherwise.
     */
    @Override
    public boolean intersects(double x, double y, double w, double h) {
        return shape.intersects( x,  y,  w,  h);
    }

    /**
     * Tests if the interior of the {@code Shape} intersects the
     * interior of a specified {@code Rectangle2D}.
     *  * @param r the specified {@code Rectangle2D}
     * @return {@code true} if the interior of the {@code Shape} and
     *          the interior of the specified {@code Rectangle2D}
     *          intersect, or are both highly likely to intersect and intersection
     *          calculations would be too expensive to perform; {@code false}
     *          otherwise.
     */
    @Override
    public boolean intersects(Rectangle2D r) {
        return shape.intersects( r);
    }

    
    /**
     * Tests if the interior of the {@code Shape} entirely contains the
     * specified {@code Rectangle2D}.
     * @param r The specified {@code Rectangle2D}
     * @return {@code true} if the interior of the {@code Shape}
     *          entirely contains the {@code Rectangle2D};
     *          {@code false} otherwise or, if the {@code Shape}
     *          contains the {@code Rectangle2D} and the
     *          {@code intersects} method returns {@code true}
     *          and the containment calculations would be too expensive to
     *          perform.
     */
    @Override
    public boolean contains(Rectangle2D r) {
        return shape.contains(r);
    }

    /**
     * Returns an iterator object that iterates along the
     * {@code Shape} boundary and provides access to the geometry of the
     * {@code Shape} outline.
     * @param at an optional {@code AffineTransform} to be applied to the
     *          coordinates as they are returned in the iteration, or
     *          {@code null} if untransformed coordinates are desired
     * @return a new {@code PathIterator} object, which independently
     *          traverses the geometry of the {@code Shape}.
     */
    @Override
    public PathIterator getPathIterator(AffineTransform at) {
        return shape.getPathIterator(at);
    }

    /**
     * Returns an iterator object that iterates along the {@code Shape}
     * boundary and provides access to a flattened view of the
     * {@code Shape} outline geometry.
     * @param at an optional {@code AffineTransform} to be applied to the
     *          coordinates as they are returned in the iteration, or
     *          {@code null} if untransformed coordinates are desired
     * @param flatness the maximum distance that the line segments used to
     *          approximate the curved segments are allowed to deviate
     *          from any point on the original curve
     * @return a new {@code PathIterator} that independently traverses
     *         a flattened view of the geometry of the  {@code Shape}.
     */
    @Override
    public PathIterator getPathIterator(AffineTransform at, double flatness) {
        return shape.getPathIterator(at,flatness);
    }
    
    /**
     *
     * @param figura
     */
//    public void setFigura(Shape figura) {
//        this.shape = figura;
//    }

    /**
     * Devuelve el color del trazo de la fígura
     * @return Color del trazo
     */
    public Color getColor() {
        return color;
    }

    /**
     * Establece el color del trazo de la fígura
     * @param color Color a establecer
     */
    public void setColor(Color color) {
        this.color = color;
    }

    /**
     * Devuelve el grosor del trazo de la figura
     * @return Grosor de la figura
     */
    public int getGrosor() {
        return grosor;
    }

    /**
     * Establece el grosor del trazo de la figura
     * @param grosor Grosor a establecer
     */
    public void setGrosor(int grosor) {
        this.grosor = grosor;
    }


    /**
     * Devuelve si se tiene que alisar la figura
     * @return Variable alisado
     */
    public boolean isAlisado() {
        return alisado;
    }

    /**
     * Establece si se tiene que alisar la figura
     * @param alisado Si se alisa o no a figura
     */
    public void setAlisado(boolean alisado) {
        this.alisado = alisado;
    }

    /**
     * Devuelve si la figura es transparente
     * @return Transparencia 
     */
    public double getTransparencia() {
        return transparencia;
    }

    /**
     * Establece si la figura es transparente
     * @param transparencia Transparencia a establecer
     */
    public void setTransparencia(double transparencia) {
        this.transparencia = transparencia;
    }


    /**
     * Devuelve el tipo de continuidad dado por un indice
     * @return Indice de continuidad
     */
    public int getTipoContinuidad() {
        return tipoContinuidad;
    }

    /**
     * Establece el tipo de continuidad de la figura
     * @param tipoContinuidad Indice de continuidad a establecer
     */
    public void setTipoContinuidad(int tipoContinuidad) {
        this.tipoContinuidad = tipoContinuidad;
    }

    /**
     * Devuelve si la figura se encuentra en modo edición
     * @return Variable booleana edicion
     */
    public boolean isEdicion() {
        return edicion;
    }

    /**
     * Establece una figura en modo edición
     * @param edicion Variable booleana a establecer.
     */
    public void setEdicion(boolean edicion) {
        this.edicion = edicion;
    }
    
    
    
    /**
     * Se encarga de pintar la figura en el lienzo.
     * @param g2d Variable de gráficos que se modificará para pintar la figura conforme a sus atributos. Se introducirá por parámetro desde el método Paint() del lienzo.
     */
    
    public void pintar_figura(Graphics2D g2d){
    RenderingHints rend_default = g2d.getRenderingHints();
    Composite comp_default = g2d.getComposite();
        
        
        Composite comp = AlphaComposite.getInstance(AlphaComposite.SRC_OVER, (float)(transparencia / 100) );
        g2d.setComposite(comp);

        if (alisado == true) {
            g2d.setRenderingHints(alisar);
        } else {
            g2d.setRenderingHints(rend_default);
        }
        float patronDiscontinuidad[] = {10f};

        BasicStroke continuidad;
        
        switch (tipoContinuidad){            
            case 1:
                continuidad = new BasicStroke(grosor,
                BasicStroke.CAP_BUTT,
                BasicStroke.JOIN_MITER, 10f,
                patronDiscontinuidad, 0f);
            break;
            default:
                continuidad = new BasicStroke(grosor);
            break;        
        }

        g2d.setStroke(continuidad);


        g2d.setColor(color);    
        g2d.draw(shape);
        
        if (edicion){
            Rectangle2D visualizar = shape.getBounds();
            
            visualizar.setFrame(visualizar.getX()- 20, visualizar.getY() - 20, visualizar.getWidth() + 40, visualizar.getHeight() + 40);
            NewRectangulo2D edit = new NewRectangulo2D(new Point(0,0), Color.BLACK, Color.BLACK, 1, 0, false, 100, 1, "");
            edit.shape = visualizar;
            edit.pintar_figura(g2d);
        }
            
        

        
        //Guardamos los valores de RenderingHints y de Composición para que no se pierdan
        g2d.setRenderingHints(rend_default);
        g2d.setComposite(comp_default);
    }
    
    
    
   
}
