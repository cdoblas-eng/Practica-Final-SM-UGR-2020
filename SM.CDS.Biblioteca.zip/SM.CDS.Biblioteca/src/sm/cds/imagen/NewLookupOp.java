/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package sm.cds.imagen;

import java.awt.image.ByteLookupTable;
import java.awt.image.LookupTable;

/**
 * Operador LookupOp propio
 * @author Doblas
 */
public class NewLookupOp {
    
    /**
     *
     * @param param_x Longitud de la llanura de la función valor del 0 al 127.
     * @param param_y Valor de la función en la meseta.
     * @return Devuelve la tabla para ser pasarla por parametro a la función operarLookUp
     */
    public static LookupTable func(int param_x, int param_y) {

        
        byte lt[] = new byte[256];
        lt[0] = 0;
        for (int l = 1; l < 256; l++) {
        
            if (l > 128 - param_x  && l < 128 + param_x )
                lt[l] = (byte) ( param_y );
            else
                lt[l] = (byte) ( l );
                
        }
        ByteLookupTable slt = new ByteLookupTable(0, lt);
        return slt;
    }
}
