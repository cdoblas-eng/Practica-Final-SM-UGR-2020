/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package sm.cds.imagen;

import java.awt.image.BufferedImage;
import java.awt.image.WritableRaster;
import sm.image.BufferedImageOpAdapter;

/**
 * Clase propia de la implementación del operador
 * @author Doblas
 */
public class NewOp extends BufferedImageOpAdapter {
    private double k;

    /**
     * Constructor de la clase NewOp, 
     * @param k Parámetro K, debera estar comprendido entre 0 y 1
     */
    public NewOp(double k) {
        this.k = k;
    }

    /**
     *
     * @param src Imagen fuente donde se va a aplicar el filtro
     * @param dest Imagen destino
     * @return Imagen con el filtro aplicado
     */
    @Override
    public BufferedImage filter(BufferedImage src, BufferedImage dest) {
        if (src == null) {
            throw new NullPointerException("src image is null");
        }
        if (dest == null) {
            dest = createCompatibleDestImage(src, null);
        }
        

        
        
        WritableRaster srcRaster = src.getRaster();
        WritableRaster destRaster = dest.getRaster();
        int[] pixelComp = new int[srcRaster.getNumBands()];
        int[] pixelCompDest = new int[srcRaster.getNumBands()];
//        int sample;
        
        //OPERACIÓN PIXEL A PIXEL
        for (int x = 0; x < src.getWidth(); x++) {
            for (int y = 0; y < src.getHeight(); y++) {
                srcRaster.getPixel(x, y, pixelComp);
                          
                pixelCompDest = pixelComp;
                //Por hacer: efecto resaltar rojo
                
                if (pixelComp[0] - pixelComp[1] - pixelComp[2] >= 0 ){
                    pixelCompDest[0] = (int) ((1+k)*pixelCompDest[0]);
                    pixelCompDest[1] = (int) (k*pixelCompDest[1]);
                    pixelCompDest[2] = (int) (k*pixelCompDest[2]);
                } 
                else
                
                if (pixelComp[1] - pixelComp[0] - pixelComp[2] >= 0 ){
                    pixelCompDest[1] = (int) ((1+k)*pixelCompDest[1]);
                    pixelCompDest[0] = (int) (k*pixelCompDest[0]);
                    pixelCompDest[2] = (int) (k*pixelCompDest[2]);
                }
                else
                
               if (pixelComp[2] - pixelComp[1] - pixelComp[0] >= 0 ){
                    pixelCompDest[2] = (int) ((1+k)*pixelCompDest[2]);
                    pixelCompDest[1] = (int) (k*pixelCompDest[1]);
                    pixelCompDest[0] = (int) (k*pixelCompDest[0]);
                }
               else{
                    pixelCompDest[0] = (int) (k*pixelCompDest[0]);;
                    pixelCompDest[1] = (int) (k*pixelCompDest[1]);
                    pixelCompDest[2] = (int) (k*pixelCompDest[2]);
               }

                destRaster.setPixel(x, y, pixelCompDest);
            }
        }
        return dest;
    }
    
}
