/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package sm.cds.imagen;

import java.awt.Color;
import java.awt.image.BufferedImage;
import java.awt.image.WritableRaster;
import sm.image.BufferedImageOpAdapter;

/**
 *
 * @author Doblas
 */
public class TintadoAutoOp extends BufferedImageOpAdapter {
    
    float color[];
    
    public TintadoAutoOp (Color color){
           
        this.color = color.getColorComponents(null);
        for (int b = 0; b < this.color.length; b++ )
            this.color[b] *= 255;
    }

    @Override
    public BufferedImage filter(BufferedImage src, BufferedImage dest) {
                if (src == null) {
            throw new NullPointerException("src image is null");
        }
        if (dest == null) {
            dest = createCompatibleDestImage(src, null);
        }
        WritableRaster srcRaster = src.getRaster();
        WritableRaster destRaster = dest.getRaster();
        int sample;
        
        int[] pixelComp = new int[srcRaster.getNumBands()];
        int[] pixelCompDest = new int[srcRaster.getNumBands()];
        
        double media_bandas = 0;
        double grado_tintado = 0; //ALFA
        
        
        for (int x = 0; x < src.getWidth(); x++) {
            for (int y = 0; y < src.getHeight(); y++) {
                srcRaster.getPixel(x, y, pixelComp);
                
                media_bandas = ( pixelComp[0] + pixelComp[1] + pixelComp[2] ) / 3;
                grado_tintado = 1 - (media_bandas /255);
          
                pixelCompDest = pixelComp;
                //Por hacer: tintar
                
                pixelCompDest[0] = (int) (   grado_tintado * color[0] + ( 1.0f - grado_tintado ) * pixelComp[0]  );
                pixelCompDest[1] = (int) (   grado_tintado * color[1] + ( 1.0f - grado_tintado ) * pixelComp[1]  );
                pixelCompDest[2] = (int) (   grado_tintado * color[2] + ( 1.0f - grado_tintado ) * pixelComp[2]  );
                
                destRaster.setPixel(x, y, pixelCompDest);
            }
        }
        return dest;
    }
    
}
