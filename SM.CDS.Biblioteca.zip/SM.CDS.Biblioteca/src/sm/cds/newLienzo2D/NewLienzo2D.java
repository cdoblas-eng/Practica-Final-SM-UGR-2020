/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package sm.cds.newLienzo2D;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Rectangle;
import java.awt.geom.Point2D;
import java.awt.image.BufferedImage;
import java.util.ArrayList;
import java.util.List;
import sm.cds.graficos.NewCurva;
import sm.cds.graficos.NewFigura;
import sm.cds.graficos.TipoHerramienta;
import sm.cds.graficos.NewElipse2D;
import sm.cds.graficos.NewFigCerrada;
import sm.cds.graficos.NewLinea2D;
import sm.cds.graficos.NewPunto2D;
import sm.cds.graficos.NewRectangulo2D;
import sm.cds.graficos.NewTrazo;

/**
 * Es la clase utilizada para representar un lienzo en la aplicación con las nuevas características.
 * @author Carlos Doblas
 */
public class NewLienzo2D extends javax.swing.JPanel {

    /**
     * Imagen almacenada en el lienzo. 
     */
    private BufferedImage imagen = null;
    /**
     * Lista de la clase Figura. Se almacenarán todas las figuras del lienzo con sus atributos.
     */
    private List<NewFigura> vShape = new ArrayList();
    /**
     * Variable que indica el tipo de relleno
     */
    private int relleno = 0;
     /**
     * Variable booleana que indica si se encuentra activo el alisado en el lienzo
     */
    private boolean alisado = false;
     /**
     * Variable booleana que indica el grado de transparencia activa en el lienzo
     */
    private double transparencia = 100;
     /**
     * Variable de tipo entero que representa el grosor activo del lienzo
     */
    private int grosor = 1;
    
    /**
     *Tipo de continuidad activo
     */
    int tipoContinuidad = 0;
    
     /**
     * Punto auxiliar que se utiliza de apoyo en varios métodos
     */
    private Point2D pAux;
     /**
     * Variable de la clase TipoHerramienta que almacena que herramienta se encuentra seleccionada en el lienzo.
     */
    private TipoHerramienta herramienta = TipoHerramienta.SIN_HERRAMIENTA;
     /**
     * Variable de la clase Color que almacena el color del trazo activo del lienzo
     */
    private Color color = Color.BLACK;
    /**
     * Variable de la clase Color que almacena el color del relleno activo del lienzo
     */
    Color color_relleno = Color.black;
    
    /**
     * Variable de la clase Figura que apunta a la figura con la que se está trabajando.
     * Se utiliza cuando se crea, se actualiza o se edita una figura.
     */
    NewFigura figura = null;
    
    /**
     * Variable que almacena la imagen del relleno de una figura cerrada a rellenar
     */
    String imagen_relleno = "";
    
    

    

    

    /**
     * Constructor de la clase Lienzo2D, no requiere parametros. Inicializa los componentes necesarios para su ejecución.
     */
    public NewLienzo2D() {  
        initComponents();
    }
    
    /**
     * Crea una figura y la añade  al vector de figuras del lienzo.
     * Crea una figura volcando las variables del lienzo en la misma
     * La figura será de un tipo o de otro dependiendo de la herramienta seleccionada.
     * @param p1 El punto de donde se va a partir a crear la figura
     */
    public void createShape(Point2D p1) {
        boolean crear = true;
        switch (herramienta) {

            case PUNTO:
                figura = new NewPunto2D(p1, color, grosor, alisado, transparencia);              
            break;
            
            case TRAZO:
                figura = new NewTrazo(p1, color, grosor, alisado, transparencia,tipoContinuidad);              
            break;
            
            case LINEA:
                figura = new NewLinea2D(p1, color, grosor, alisado, transparencia, tipoContinuidad);
            break;

            case RECTANGULO:
                pAux = p1;
                figura = new NewRectangulo2D(p1, color, color_relleno, grosor, relleno, alisado, transparencia, tipoContinuidad,imagen_relleno);             
            break;
            
            case OVALO:
                pAux = p1;
                figura = new NewElipse2D(p1, color, color_relleno, grosor, relleno, alisado, transparencia, tipoContinuidad,imagen_relleno);
            break;
            
            case CURVA:
                if ( !( ( figura instanceof NewCurva ) && ((NewCurva) figura).getEstado() != 2 ) ){
                    pAux = p1;
                    figura = new NewCurva(p1, color, grosor, alisado, transparencia, tipoContinuidad);
                }
                  
            break;
            case SIN_HERRAMIENTA:
                crear = false;
            break;
                
        }
        if (crear){
            vShape.add(figura);
            this.repaint();
        }
    }


    /**
     * Metodo Paint de mi clase lienzo, se encarga de llamar al método pintar_figura de cada figura almacenada en el vector de figuras.
     * Así se van dibujando cada figura con sus respectivos atributos.
     * @param g Gráficos del jPanel (Lienzo).
     */
    @Override
    public void paint(Graphics g) {
        super.paint(g);
        Graphics2D g2d = (Graphics2D) g;
                
        if (imagen != null) {
            g2d.drawImage(imagen, 0, 0, this);
            g2d.clip(new Rectangle(0, 0, imagen.getWidth(), imagen.getHeight()));
        }
           
        for (NewFigura s : vShape) { //Para cada figura del vector
            s.pintar_figura(g2d); //Pinta cada figura
        }
    }

    /**
     * Devuelve una figura si un punto p se encuentra contenido dentro de la misma.
     * @param p Punto del lienzo donde queremos comprobar si hay una figura.
     * @return NewFigura encontrada o null en el caso de no encontrarla
     */
    public NewFigura getSelectedShape(Point2D p){
        for(NewFigura s:vShape)
            if(s.contains(p)) return s;        
        return null;
    }
    
    /**
     * Establece la herramienta activa del lienzo
     * @param herramienta Herramienta de la clase TIpoHerramienta a establecer.
     */
    public void setHerramienta(TipoHerramienta herramienta) {  
        if (figura != null) {
            figura.setEdicion(false);
            this.repaint();
        }
        this.herramienta = herramienta;  }

    /**
     * Devuelve la herramienta seleccionada activa del Lienzo
     * @return Herramienta seleccionada
     */
    public TipoHerramienta getHerramienta() {  return herramienta;  }

    /**
     * Devuelve el color del trazo activo del Lienzo
     * @return Color del trazo
     */
    public Color getColor()  {  return color;  }
    
    /**
     * Cambia el color del trazo activo del Lienzo
     * @param color Color del trazo a establecer
     */
    public void cambiarColor (Color color){
        this.color = color;
        if (herramienta == TipoHerramienta.EDICION && figura != null){
            figura.setColor(this.color);
        }
        this.repaint();
    }

    /**
     * Devuelve el color del relleno activo del Lienzo
     * @return Color del relleno
     */
    public Color getColor_relleno() {
        return color_relleno;
    }

    /**
     * Cambia el color del relleno activo del Lienzo
     * @param color_relleno Color de relleno a establecer
     */
    public void cambiarColorRelleno(Color color_relleno) {
        this.color_relleno = color_relleno;
        if (herramienta == TipoHerramienta.EDICION && figura != null && figura instanceof NewFigCerrada){
            ((NewFigCerrada)  figura).setColor_relleno(this.color_relleno);
        }
        this.repaint();
    }

    /**
     * Devuelve el atributo relleno del Lienzo
     * @return Relleno Variable entero, indica el tipo de relleno
     */
    public int getRelleno() {
        return relleno;
    }
    
    /**
     * Establece el tipo de relleno activo del lienzo
     */
    public void setRelleno (int relleno){
        this.relleno = relleno;
        if (herramienta == TipoHerramienta.EDICION && figura != null && figura instanceof NewFigCerrada){
              ((NewFigCerrada)  figura).setRelleno(this.relleno);
        }
        this.repaint();
    }
    
    /**
     * Cambia el grosor activo del lienzo
     * @param grosor Grosor a establecer
     */
    public void cambiarGrosor (int grosor){
        this.grosor = grosor;
        if (herramienta == TipoHerramienta.EDICION && figura != null){
                figura.setGrosor(this.grosor);
        }
        this.repaint();
    }

    /**
     * Devuelve la figura con la que se está trabajando
     * @return NewFigura actual
     */
    public NewFigura getFigura() {
        return figura;
    }

    /**
     * Devuelve el grosor activo del Lienzo
     * @return Grosor 
     */
    public int getGrosor()  {  return grosor;  }

    /**
     * Devuelve si se encuentra activo el alisado en el lienzo
     * @return Variable booleana que indica si se establece el alisado.
     */
    public boolean isAlisado()  {  return alisado;  }

    /**
     * Establece el alisado activo en el lienzo
     * @param alisado Variable booleana alisado a establecer
     */
    public void setAlisado(boolean alisado)  {  
        this.alisado = alisado;  
        if (herramienta == TipoHerramienta.EDICION && figura != null){
            figura.setAlisado(this.alisado);
            this.repaint();
        }
    }

    /**
     * Devuelve si se encuentra activa la transparencia en el lienzo
     * @return Variable booleana que indica si hay transparencia.
     */
    public double getTransparencia()  {  return transparencia;   }

    /**
     * Establece la transparencia activa en el lienzo
     * @param transparencia Variable booleana que establece la transparencia.
     */
    public void setTransparencia(double transparencia)  {  
        this.transparencia = transparencia;
        if (herramienta == TipoHerramienta.EDICION && figura != null){
            figura.setTransparencia(this.transparencia);
            this.repaint();
        }
    
    }
/**
     * Establece el tipo de continuidad activo del lienzo
     * @param tipoContinuidad Indice de continuidad a establecer
     */
    public void setTipoContinuidad(int tipoContinuidad) {
        this.tipoContinuidad = tipoContinuidad;
        if (herramienta == TipoHerramienta.EDICION && figura != null){
            figura.setTipoContinuidad(this.tipoContinuidad);
            this.repaint();
        }
    }

    /**
     * Devuelve el tipo de continuidad activo dado por un indice
     * @return Indice de continuidad
     */
    public int getTipoContinuidad() {
        return tipoContinuidad;
    }
    
    
    
    
    /**
     * Establece una imagen en el lienzo
     * @param img Imagen de la clase BufferedImage a establecer
     */
    public void setImagen(BufferedImage img)  {  
        imagen = img;  
        if (  img !=null  )  
            setPreferredSize(new Dimension(img.getWidth(),img.getHeight()));
    }
        
    /**
     * Actualiza los atributos activos del lienzo dada una figura. Se utiliza cuando estamos editando una figura.
     * @param f Variable de la clase NewFigura de la que se obtienen los atributos
     */
    public void establecer_atributos_figura(NewFigura f){
        
        this.color = f.getColor();
        this.grosor = f.getGrosor();  
        this.alisado = f.isAlisado();;
        this.transparencia = f.getTransparencia();
        this.tipoContinuidad = f.getTipoContinuidad();
        
        if (f instanceof NewFigCerrada) {
            this.color_relleno = ((NewFigCerrada) f).getColor_relleno();
            this.relleno = ((NewFigCerrada) f).getRelleno();
            this.imagen_relleno = ((NewFigCerrada) f).getImagen_relleno();
        }
    }
    
    /**
     * Devuelve la imagén almacenada en el lienzo
     * @param drawVector Variable booleana, si vale true se devuelve la imagen con y se vuelcan las figuras dibujadas, si vale false solo devuelve la imagen.
     * @return Imagen del lienzo
     */
    public BufferedImage getImagen(boolean drawVector) {
        if (drawVector) {
            BufferedImage imgout = new BufferedImage(imagen.getWidth(), imagen.getHeight(), imagen.getType());
            boolean opacoActual = this.isOpaque();

            if (imagen.getColorModel().hasAlpha()) {
                this.setOpaque(false);
            }
            this.paint(imgout.createGraphics());
            this.setOpaque(opacoActual);
            return imgout;
        }
        return imagen ;
    }
    
    /**
     * Metodo que vuelca todas las figuras almacenadas en el vector de figuras a la imagen del mismo.
     */
    public void volcarFiguras(){
        imagen = getImagen(true);
        vShape.clear();
    }

    /**
     * This method is called from within the constructor to initialize the form.
     * WARNING: Do NOT modify this code. The content of this method is always
     * regenerated by the Form Editor.
     */
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        addMouseMotionListener(new java.awt.event.MouseMotionAdapter() {
            public void mouseDragged(java.awt.event.MouseEvent evt) {
                formMouseDragged(evt);
            }
        });
        addMouseListener(new java.awt.event.MouseAdapter() {
            public void mousePressed(java.awt.event.MouseEvent evt) {
                formMousePressed(evt);
            }
            public void mouseReleased(java.awt.event.MouseEvent evt) {
                formMouseReleased(evt);
            }
        });
        setLayout(new java.awt.BorderLayout());
    }// </editor-fold>//GEN-END:initComponents

    private void formMousePressed(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_formMousePressed
        if (herramienta != TipoHerramienta.EDICION)    {
            pAux = evt.getPoint();
            createShape(evt.getPoint());
        // Si queremos editar
        } else {    
            pAux = evt.getPoint();
            NewFigura anterior,seleccionada = null;
            anterior = null;
            
            if (figura != null)
                anterior = figura;
            
            seleccionada = getSelectedShape(evt.getPoint());
            if (seleccionada != null)
                figura = seleccionada;
            
            if (figura != null){
                if (anterior != figura)
                    anterior.setEdicion(false);
                
                establecer_atributos_figura(figura);
                figura.setEdicion(true);
                this.repaint();
            }
        }
    }//GEN-LAST:event_formMousePressed

    private void formMouseReleased(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_formMouseReleased
        if (herramienta != TipoHerramienta.EDICION && figura != null)    {
            figura.update_figura(pAux, evt.getPoint());
            
            if (figura instanceof NewCurva)
                ((NewCurva) figura).cambiarEstado();
            
            //figura = null;
        }
        this.repaint();
    }//GEN-LAST:event_formMouseReleased

    private void formMouseDragged(java.awt.event.MouseEvent evt) {//GEN-FIRST:event_formMouseDragged
        if (herramienta != TipoHerramienta.EDICION && figura != null)    {
            figura.update_figura(pAux, evt.getPoint());
        }
        else if (figura != null)   {
            
            //Si está activada la opción de editar
            figura.mover_figura(evt.getPoint(), pAux);
            pAux = evt.getPoint();
        }
        this.repaint();
    }//GEN-LAST:event_formMouseDragged

    public String getImagen_relleno() {
        return imagen_relleno;
    }

    public void setImagen_relleno(String imagen_relleno) {
        
        this.imagen_relleno = imagen_relleno;
        if (herramienta == TipoHerramienta.EDICION && figura != null && figura instanceof NewFigCerrada){
              ((NewFigCerrada)  figura).setImagen_relleno(this.imagen_relleno);
        }
        this.repaint();
    }

    
    // Variables declaration - do not modify//GEN-BEGIN:variables
    // End of variables declaration//GEN-END:variables
}
